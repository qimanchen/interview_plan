<form action="<?php bloginfo('siteurl'); ?>" id="searchform" method="get">
    <div>
        <label for="s" class="screen-reader-text">Search for:</label>
        <input  type="text" id="s" name="s"  onfocus="if (value =='从这里搜索，按enter开始'){value =''}" onblur="if (value ==''){value='从这里搜索，按enter开始'}" value="从这里搜索，按enter开始" />
        
       
      
    </div>
</form>