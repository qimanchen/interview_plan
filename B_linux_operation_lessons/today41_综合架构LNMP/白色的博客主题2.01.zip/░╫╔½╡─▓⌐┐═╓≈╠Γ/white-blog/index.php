<?php get_header(); ?>

  
  
 <!--ijaoover-->

<div class="maim">

           
   
   
       <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/xuant.js"></script>
       
       
   <div class="jiao">
   
   <DIV id=imgPlay>

     <div class="zhezhao_left"></div>
    <div class="zhezhao_right"></div>
<UL class=imgs id=actor>

<?php if (get_option('mytheme_about_img6')!=""): ?>

<LI> 
 <div class="imgplay_wen"> 
 <h1><?php echo get_option('mytheme_about_entit6'); ?></h1><h1><?php echo get_option('mytheme_about_tit6'); ?></h1>
 <p><?php echo mb_strimwidth(strip_tags(get_option('mytheme_about_text6')), 0,180,"..."); ?></p>
 </div>
 <a href="<?php echo get_option('mytheme_about_url6'); ?>"><img src="<?php echo get_option('mytheme_about_img6'); ?>"  /></a>
</LI> 
<?php else : ?>  

<LI> 
 <div class="imgplay_wen"> 
 <h1>THE GREAT THEME OF FANTASTIC</h1><h1>白色精简的博客主题</h1>
 <p>这个主题是一款非常轻量，简洁的主题，没有过多繁杂，使得书写博客更容易被接受，插件的安装也仅仅是一个相册管理和lightbox的插件，如果不喜欢，可以不安装他们，对博客的影响也不会很大...</p>
 </div>
 <img src="<? bloginfo('template_url'); ?>/images/jiao_06.gif"  />
</LI> 
      <?php endif; ?> 





<?php if (get_option('mytheme_about_img7')!=""): ?>

<LI> 
 <div class="imgplay_wen"> 
 <h1><?php echo get_option('mytheme_about_entit7'); ?></h1><h1><?php echo get_option('mytheme_about_tit7'); ?></h1>
 <p><?php echo mb_strimwidth(strip_tags(get_option('mytheme_about_text7')), 0,180,"..."); ?></p>
 </div>
 <a href="<?php echo get_option('mytheme_about_url7'); ?>"><img src="<?php echo get_option('mytheme_about_img7'); ?>"  /></a>
</LI> 
<?php else : ?>  

<LI> 
 <div class="imgplay_wen"> 
 <h1>THE GREAT THEME OF FANTASTIC</h1><h1>白色精简的博客主题</h1>
 <p>这个主题是一款非常轻量，简洁的主题，没有过多繁杂，使得书写博客更容易被接受，插件的安装也仅仅是一个相册管理和lightbox的插件，如果不喜欢，可以不安装他们，对博客的影响也不会很大...</p>
 </div>
 <img src="<? bloginfo('template_url'); ?>/images/jiao_07.gif"  />
</LI> 
      <?php endif; ?> 





<?php if (get_option('mytheme_about_img8')!=""): ?>

<LI> 
 <div class="imgplay_wen"> 
 <h1><?php echo get_option('mytheme_about_entit8'); ?></h1><h1><?php echo get_option('mytheme_about_tit8'); ?></h1>
 <p><?php echo mb_strimwidth(strip_tags(get_option('mytheme_about_text8')), 0,180,"..."); ?></p>
 </div>
 <a href="<?php echo get_option('mytheme_about_url8'); ?>"><img src="<?php echo get_option('mytheme_about_img8'); ?>"  /></a>
</LI> 
<?php else : ?>  

<LI> 
 <div class="imgplay_wen"> 
 <h1>THE GREAT THEME OF FANTASTIC</h1><h1>白色精简的博客主题</h1>
 <p>这个主题是一款非常轻量，简洁的主题，没有过多繁杂，使得书写博客更容易被接受，插件的安装也仅仅是一个相册管理和lightbox的插件，如果不喜欢，可以不安装他们，对博客的影响也不会很大...</p>
 </div>
 <img src="<? bloginfo('template_url'); ?>/images/jiao_07.gif"  />
</LI>       <?php endif; ?> 




<?php if (get_option('mytheme_about_img9')!=""): ?>

<LI> 
 <div class="imgplay_wen"> 
 <h1><?php echo get_option('mytheme_about_entit9'); ?></h1><h1><?php echo get_option('mytheme_about_tit9'); ?></h1>
 <p><?php echo mb_strimwidth(strip_tags(get_option('mytheme_about_text9')), 0,180,"..."); ?></p>
 </div>
 <a href="<?php echo get_option('mytheme_about_url9'); ?>"><img src="<?php echo get_option('mytheme_about_img9'); ?>"  /></a>
</LI> 
<?php else : ?>  

<LI> 
 <div class="imgplay_wen"> 
 <h1>THE GREAT THEME OF FANTASTIC</h1><h1>白色精简的博客主题</h1>
 <p>这个主题是一款非常轻量，简洁的主题，没有过多繁杂，使得书写博客更容易被接受，插件的安装也仅仅是一个相册管理和lightbox的插件，如果不喜欢，可以不安装他们，对博客的影响也不会很大...</p>
 </div>
 <img src="<? bloginfo('template_url'); ?>/images/jiao_07.gif"  />
</LI>       <?php endif; ?> 
 





<?php if (get_option('mytheme_about_img0')!=""): ?>

<LI> 
 <div class="imgplay_wen"> 
 <h1><?php echo get_option('mytheme_about_entit0'); ?></h1><h1><?php echo get_option('mytheme_about_tit0'); ?></h1>
 <p><?php echo mb_strimwidth(strip_tags(get_option('mytheme_about_text0')), 0,180,"..."); ?></p>
 </div>
 <a href="<?php echo get_option('mytheme_about_url0'); ?>"><img src="<?php echo get_option('mytheme_about_img0'); ?>"  /></a>
</LI> 
<?php else : ?>  

<LI> 
 <div class="imgplay_wen"> 
 <h1>THE GREAT THEME OF FANTASTIC</h1><h1>白色精简的博客主题</h1>
 <p>这个主题是一款非常轻量，简洁的主题，没有过多繁杂，使得书写博客更容易被接受，插件的安装也仅仅是一个相册管理和lightbox的插件，如果不喜欢，可以不安装他们，对博客的影响也不会很大...</p>
 </div>
 <img src="<? bloginfo('template_url'); ?>/images/jiao_07.gif"  />
</LI>       <?php endif; ?> 


</UL>


<DIV class=prev><img src="<? bloginfo('template_url'); ?>/images/prev.png" /></DIV>
<DIV class=next><img src="<? bloginfo('template_url'); ?>/images/next.png" /></DIV></DIV>
   
   
   </div> 
    
    <div class="main3"> 
    
    
    <div class="leftmain5">
    <div class="news_show">
  
    
      <div class="about_wen2">

  
    
    <ul>
 
     <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <li>
             <a class="bt" href="<?php the_permalink() ?>"> <h1><?php the_title(); ?> </h1></a>
             <a class="time" href="#"><?php the_time('m-d-y') ?></a>
             <hr class="heng" />
             <?php the_post_thumbnail(); ?>
            <div  class="entry">
			 <?php the_content(); ?>
             </div>
             <a class="li_btn" href="<?php the_permalink() ?>">阅读全文>></a>
       <div class="in-di"><img src="<? bloginfo('template_url'); ?>/images/in_di.png" /></div>
       </li>
       
       
      
       <?php endwhile; ?>     
          
      



	<?php else : ?>
       
         
        <?php  endif; ?>   

         
    </ul>
            
             
    <div class="pager">   <?php par_pagenavi(); ?>  </div>
  
  

         
     </div>
            

   </div>
    
    
    </div>
    
    
    
    <div class="rightmain2">
    <?php include_once("sidebar.php"); ?>
    <div class="coffi"><img src="<? bloginfo('template_url'); ?>/images/pages/coffie.png" /></div>
    </div>
   
   
   
   </div>
    
    
    
    
    </div>







<?php get_footer(); ?>
